package com.yuu.recruit.utils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.util.Objects;

public class SessionUtils {

    /**
     * 获取sessionId
     *
     * @param request  请求
     * @return sessionId
     */
    public static String getSessionId(HttpServletRequest request) {
        // request为空返回null
        if (Objects.isNull(request)) {
            return null;
        }
        // 优先取请求里的JSSESSIONID
        String sessionId = request.getRequestedSessionId();
        // 如果为空，需要新建一个
        if (sessionId.isEmpty()) {
            HttpSession httpSession = request.getSession();
            // 为空返回null
            if (Objects.isNull(httpSession)) {
                return null;
            }
            sessionId = httpSession.getId();
        }
        return sessionId;
    }
}
