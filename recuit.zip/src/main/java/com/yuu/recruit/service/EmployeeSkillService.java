package com.yuu.recruit.service;

/**
 * @author by yuu
 * @Classname ${NAME}
 * @Date 2019/10/16 1:15
 * @see ${PACKAGE_NAME}
 */
public interface EmployeeSkillService {


}

