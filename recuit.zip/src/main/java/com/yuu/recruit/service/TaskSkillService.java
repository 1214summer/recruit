package com.yuu.recruit.service;

/**
 * 任务技能业务逻辑接口
 */
public interface TaskSkillService {


    /**
     * 添加任务技能
     *
     * @param skills
     */
    void addTaskSkills(String skills);
}

