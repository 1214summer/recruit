package com.yuu.recruit.mapper;

import com.yuu.recruit.domain.EmployeeSkill;
import tk.mybatis.mapper.MyMapper;

public interface EmployeeSkillMapper extends MyMapper<EmployeeSkill> {
}
