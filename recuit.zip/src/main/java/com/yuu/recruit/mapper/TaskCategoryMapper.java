package com.yuu.recruit.mapper;

import com.yuu.recruit.domain.TaskCategory;
import tk.mybatis.mapper.MyMapper;

public interface TaskCategoryMapper extends MyMapper<TaskCategory> {
}
