package com.yuu.recruit.mapper;

import com.yuu.recruit.domain.Task;
import tk.mybatis.mapper.MyMapper;

public interface TaskMapper extends MyMapper<Task> {
}
