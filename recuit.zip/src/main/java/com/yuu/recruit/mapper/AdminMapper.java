package com.yuu.recruit.mapper;

import com.yuu.recruit.domain.Admin;
import tk.mybatis.mapper.MyMapper;

public interface AdminMapper extends MyMapper<Admin> {
}
