package com.yuu.recruit.mapper;

import com.yuu.recruit.domain.Employer;
import tk.mybatis.mapper.MyMapper;

public interface EmployerMapper extends MyMapper<Employer> {
}
