package com.yuu.recruit.mapper;

import com.yuu.recruit.domain.Employee;
import tk.mybatis.mapper.MyMapper;

public interface EmployeeMapper extends MyMapper<Employee> {
}
