package com.yuu.recruit.mapper;

import com.yuu.recruit.domain.TaskSkill;
import tk.mybatis.mapper.MyMapper;

public interface TaskSkillMapper extends MyMapper<TaskSkill> {
}
