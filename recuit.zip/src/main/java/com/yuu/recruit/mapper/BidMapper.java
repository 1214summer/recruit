package com.yuu.recruit.mapper;

import com.yuu.recruit.domain.Bid;
import tk.mybatis.mapper.MyMapper;

public interface BidMapper extends MyMapper<Bid> {
}
