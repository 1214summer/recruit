package com.yuu.recruit.mapper;

import com.yuu.recruit.domain.HomeBower;
import tk.mybatis.mapper.MyMapper;

public interface HomeBowerMapper extends MyMapper<HomeBower> {
}
