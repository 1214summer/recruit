package com.yuu.recruit.mapper;

import com.yuu.recruit.domain.EmployeeBookmarked;
import tk.mybatis.mapper.MyMapper;

public interface EmployeeBookmarkedMapper extends MyMapper<EmployeeBookmarked> {
}
