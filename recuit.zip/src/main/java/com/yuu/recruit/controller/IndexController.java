package com.yuu.recruit.controller;

import com.yuu.recruit.common.R;
import com.yuu.recruit.domain.Employee;
import com.yuu.recruit.domain.Employer;
import com.yuu.recruit.service.EmployeeService;
import com.yuu.recruit.service.EmployerService;
import com.yuu.recruit.service.TaskCategoryService;
import com.yuu.recruit.service.TaskService;
import com.yuu.recruit.vo.TaskCategoryVo;
import com.yuu.recruit.vo.TaskVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * 系统首页控制器
 *
 * @author by yuu
 * @Classname IndexController
 * @Date 2019/10/14 12:26
 * @see com.yuu.recruit.controller
 */
@RestController
@Slf4j
public class IndexController {

    @Resource
    private TaskCategoryService taskCategoryService;

    @Resource
    private TaskService taskService;

    @Resource
    private EmployeeService employeeService;

    @Resource
    private EmployerService employerService;

    /**
     * 跳转到系统首页，使用 localhost:8080 和 localhost:8080/index 都可以访问
     *
     * @return
     */
    @GetMapping({"", "/index"})
    public R<List<TaskCategoryVo>> taskCategoryVos() {

        // 查询所有任务分类, 为什么要用 Vo 对象，因为首页展示的热门分类中需要显示，该分类的任务数量，所以需要创建一个 Vo 对象，来包含分类任务数量信息
        List<TaskCategoryVo> taskCategoryVos = taskCategoryService.getAll();

        return R.success(taskCategoryVos);
    }
    @GetMapping({"", "/index1"})
    public R<Integer> taskCount() {
        Integer taskCount = taskService.getAllCount();
        return R.success(taskCount);
    }

    @GetMapping({"", "/index2"})
    public R<Integer> employeeCount() {
        Integer employeeCount = employeeService.getAllCount();
        return R.success(employeeCount);
    }

    @GetMapping({"", "/index3"})
    public R<Integer> employerCount() {
        Integer employerCount = employerService.getAllCount();
        return R.success(employerCount);
    }

    @GetMapping({"", "/index4"})
    public R<List<TaskCategoryVo>> popularCategories() {
        List<TaskCategoryVo> popularCategories = taskCategoryService.getPopular();
        return R.success(popularCategories);
    }

    @GetMapping({"", "/index5"})
    public R<List<TaskVo>> recentTaskVos() {
        List<TaskVo> recentTaskVos =  taskService.getRecently();
        return R.success(recentTaskVos);
    }

    /**
     * 用户注册，包括雇员和雇主，通过传过来的 accountType 判断
     *
     * @return
     */
    @PostMapping("register_publisher")
    public R<String> register_publisher(@RequestParam String username,@RequestParam String password) {
            Employer employer = employerService.getByUsername(username);
            if (employer != null) {
                return R.error("用户名已被注册");
            }
            employerService.register(username, password);
            return R.success("注册成功");
    }

    @PostMapping("register_performer")
    public R<String> register_performer(@RequestParam String username,@RequestParam String password) {
        Employee employee = employeeService.getByUsername(username);
        if (employee != null) {
            return R.error("用户名已被注册");
        }
        employeeService.register(username, password);
        return R.success("注册成功");
    }

    @PostMapping("login_publisher")
    public R<String> login_publisher(@RequestParam String username,@RequestParam String password) {
        log.info(username);
        log.info(password);
        Employer employer = employerService.login(username, password);
        if(employer != null) {
            return R.success(String.valueOf(employer.getId()));
        }
        else return R.error("用户名或密码错误");
    }

    @PostMapping("login_performer")
    public R<String> login_performer(@RequestParam String username,@RequestParam String password) {
        log.info(username);
        log.info(password);
        Employee employee = employeeService.login(username, password);
        if(employee != null) {
            return R.success(String.valueOf(employee.getId()));
        }
        else return R.error("用户名或密码错误");
    }
}
