package com.yuu.recruit.controller;

import com.yuu.recruit.common.R;
import com.yuu.recruit.domain.Employee;
import com.yuu.recruit.result.PageResult;
import com.yuu.recruit.service.EmployeeBookmarkedService;
import com.yuu.recruit.service.TaskCategoryService;
import com.yuu.recruit.service.TaskService;
import com.yuu.recruit.vo.TaskCategoryVo;
import com.yuu.recruit.vo.TaskVo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

/**
 * 任务控制器
 *
 * @author by yuu
 * @Classname TaskController
 * @Date 2019/10/14 17:18
 * @see com.yuu.recruit.controller
 */
@RestController
@RequestMapping("task")
public class TaskController {

    @Resource
    private TaskService taskService;

    @Resource
    private TaskCategoryService taskCategoryService;

    @Resource
    private EmployeeBookmarkedService employeeBookmarkedService;

    /**
     * 跳转到分类列表页
     *
     * @return
     */
    @GetMapping("idlist")
    public R<List<Long>> idlist(HttpServletRequest request) {
        // 如果雇员登录了，查询出雇员收藏信息
        Employee employee = (Employee) request.getSession().getAttribute("employee");
        List<Long> bookMarkedIds = new ArrayList<>();
        if (employee != null) {
            // 查询雇员收藏信息
            Long employeeId = employee.getId();
            // 查询雇员收藏任务ID集合
            bookMarkedIds = employeeBookmarkedService.getIdsByEmployeeId(employeeId);
        }
        return R.success(bookMarkedIds);
    }

    @GetMapping("TaskCategoryVo")
    public R<List<TaskCategoryVo>> TaskCategoryVo() {
        List<TaskCategoryVo> taskCategories = taskCategoryService.getAll();
        return R.success(taskCategories);
    }

    @GetMapping("PageResult")
    public R<PageResult<TaskVo>> PageResult(@RequestParam(defaultValue = "0") Long categoryId,
                                            @RequestParam(defaultValue = "") String key,
                                            @RequestParam(defaultValue = "1") int page) {
        PageResult<TaskVo> tasksPage = taskService.page(categoryId, key, page);
        return R.success(tasksPage);
    }

    /**
     * 跳转到任务详情页
     *
     * @param taskId 任务 ID
     * @return
     */
    @GetMapping("taskInfo")
    public R<TaskVo> page(@RequestParam(required = true) Long taskId) {
        // 根据任务 ID 查询出任务详情
        TaskVo taskVo = taskService.getById(taskId);
        return R.success(taskVo);
    }

}
