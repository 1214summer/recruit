package com.yuu.recruit.controller;

import com.yuu.recruit.common.R;
import com.yuu.recruit.domain.Admin;
import com.yuu.recruit.domain.TaskCategory;
import com.yuu.recruit.service.TaskCategoryService;
import com.yuu.recruit.vo.TaskCategoryVo;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.List;

/**
 * 管理员管理任务分类控制器
 *
 * @author by yuu
 * @Classname AdminTaskCategoryController
 * @Date 2019/10/13 21:10
 * @see com.yuu.recruit.controller
 */
@RestController
@RequestMapping("admin/task/category")
public class AdminTaskCategoryController {

    @Resource
    private TaskCategoryService taskCategoryService;

    /**
     * 查询所有分类
     *
     * @return
     */
    @GetMapping("")
    public R<List<TaskCategoryVo>> taskCategory() {
        List<TaskCategoryVo> taskCategories = taskCategoryService.getAll();
        return R.success(taskCategories);
    }

    /**
     * 任务分类列表页，添加/编辑都在这个页面，通过 ID 判断是编辑还是删除
     *
     * @return
     */
    @GetMapping("form")
    public R<TaskCategory> form(@RequestParam Long id) {

        // 如果 ID 不为空则编辑任务分类，用 ID 去数据库查询出分类信息
        if (id != null) {
            TaskCategory taskCategory = taskCategoryService.getById(id);
            return R.success(taskCategory);
        }
        return R.error("获取失败");
    }

    /**
     * 保存任务分类信息
     *
     * @param taskCategory 任务分类
     * @return
     */
    @PostMapping("save")
    public R<String> save(@RequestBody TaskCategory taskCategory) {
        taskCategoryService.save(taskCategory);
        return R.success("保存成功");
    }

    /**
     * 删除任务分类信息
     *
     * @param id
     * @return
     */
    @GetMapping("delete/{id}")
    public R<String> delete(@PathVariable Long id) {
        taskCategoryService.delete(id);
        return R.success("删除成功");
    }
}
