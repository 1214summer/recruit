package com.yuu.recruit.controller;

import com.yuu.recruit.common.R;
import com.yuu.recruit.domain.Employer;
import com.yuu.recruit.domain.Task;
import com.yuu.recruit.service.BidService;
import com.yuu.recruit.service.EmployerService;
import com.yuu.recruit.service.TaskCategoryService;
import com.yuu.recruit.service.TaskService;
import com.yuu.recruit.vo.TaskCategoryVo;
import com.yuu.recruit.vo.TaskVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.Collections;
import java.util.List;

/**
 * 雇主控制器
 *
 * @author by yuu
 * @Classname EmployerController
 * @Date 2019/10/15 21:30
 * @see com.yuu.recruit.controller
 */
@Slf4j
@RestController
@RequestMapping("employer")
public class EmployerController {

    @Resource
    private TaskService taskService;

    @Resource
    private TaskCategoryService taskCategoryService;

    @Resource
    private BidService bidService;

    @Resource
    private EmployerService employerService;

    /**
     * 雇主退出登录
     *
     * @param
     * @return
     */
    //发布者信息
    @GetMapping("getInfo")
    public R<Employer> getInfo(@RequestParam String employerId) {
        Employer employer = employerService.getById(Long.valueOf(employerId));
        log.info(String.valueOf(employer));
        return R.success(employer);
    }

    @PostMapping("saveInfo")
    public R<Employer> saveInfo(@RequestBody Employer employer) {
        log.info(String.valueOf(employer));
        Employer currEmployer = employerService.save(employer);
        log.info(String.valueOf(currEmployer));
        return R.success(currEmployer);
    }


    @PostMapping("taskNum")
    public R<Integer> dashboard1(HttpServletRequest request) {
        Employer employer = (Employer) request.getSession().getAttribute("employer");
        List<TaskVo> tasks = taskService.getByEmployerId(employer.getId());
        Integer taskCount = tasks != null ? tasks.size() : 0;
        return R.success(taskCount);
    }

    @PostMapping("peoNum")
    public R<Integer> dashboard2(HttpServletRequest request) {
        Employer employer = (Employer) request.getSession().getAttribute("employer");
        Integer bidCount = taskService.getBidCount(employer.getId());
        return R.success(bidCount);
    }

    @PostMapping("taskComple")
    public R<List<TaskVo>> dashboard3(HttpServletRequest request) {
        Employer employer = (Employer) request.getSession().getAttribute("employer");
        List<TaskVo> taskVos = taskService.getRecentlySubmit(employer.getId());
        return R.success(taskVos);
    }
    /**
     * 跳转到任务发布页面
     *
     * @return
     */
    @GetMapping("taskCategorys")
    public R<List<TaskCategoryVo>> postTask() {
        // 查询出所有任务分类信息
        List<TaskCategoryVo> taskCategoryVos = taskCategoryService.getAll();
        return R.success(taskCategoryVos);
    }

    /**
     * 雇主发布一个任务
     *
     * @param
     * @return
     */

    @PostMapping("task/post")
    public R<String> postTask(@RequestParam String employerId, @RequestBody Task task,@RequestParam String skills) {
        log.info(employerId);
        log.info(String.valueOf(task));
        log.info(skills);
        task.setEmployerId(Long.valueOf(employerId));
        taskService.postTask(task, skills);
        return R.success("发布任务成功，等待管理员审核！");
    }

    /**
     * 跳转到我的任务页面
     * @param
     * @return
     */
    @GetMapping("myTasks")
    public R<List<TaskVo>> myTask(@RequestParam String employerId) {
        // 查询雇主的所有任务
        List<TaskVo> taskVos = taskService.getByEmployerId(Long.valueOf(employerId));

        return R.success(taskVos);
    }


    @GetMapping("getTaskInfo")
    public R<TaskVo> updateTask(@RequestParam("taskId") Long taskId){
        TaskVo taskVo = taskService.getById(taskId);
        return R.success(taskVo);
    }

    /**
     * 添加技能
     *
     * @param skillName 技能名称
     * @return
     */
    @GetMapping("skill/add")
    public R<Long> addSkill(@RequestParam String skillName,@RequestParam Long taskId) {
        if (!"".equals(skillName)) {
            Long skillId=employerService.addSkill(taskId, skillName);
            return R.success(skillId);
        }
        return R.error("添加失败");
    }
    @GetMapping("skills/add")
    public R<List<Long>> addSkills(@RequestParam String skillName, @RequestParam Long taskId) {
        if (!"".equals(skillName)) {
            List<Long> skillId=employerService.addSkills(taskId, skillName);
            return R.success(skillId);
        }
        return R.error("添加失败");
    }


    /**
     * 删除技能
     *
     * @param skillId
     * @return
     */
    @GetMapping("skill/delete")
    public R<String> deleteSkill(@RequestParam Long skillId) {
        employerService.deleteSkill(skillId);
        return R.success("删除技能成功");
    }

    /**
     * 更新任务
     *
     * @param task 任务
     * @return
     */
    @PostMapping("task/update")
    public R<String> updateTask(@RequestBody Task task) {
        taskService.updateTask(task);
        // 提示消息
        return R.success("更新任务成功，等待管理员审核！");
    }

    /**
     * 删除任务
     *
     * @param taskId 任务 ID
     * @return
     */
    @GetMapping("task/delete")
    public R<String> deleteTask(@RequestParam("taskId") Long taskId) {
        taskService.deleteById(taskId);
        return R.success("删除成功");
    }


    /**
     * 中标：接受投标
     *
     * @param taskId
     * @return
     */
    @GetMapping("acceptBid")
    public R<String> acceptBid(@RequestParam String employeeId,@RequestParam Long taskId) {
        bidService.acceptBid(taskId, Long.valueOf(employeeId));
        return R.success("添加成功");
    }

    /**
     * 确定完成任务
     *
     * @param taskId
     * @return
     */
    @GetMapping("task/success")
    public R<String> successTask(@RequestParam Long taskId) {
        taskService.successTask(taskId);
        return R.success("已完成");
    }

    /**
     * 修改密码
     *
     * @param password 原来的密码
     * @param newPassword 新密码
     * @return
     */
    @GetMapping("updatePwd")
    public R<String> updatePass(@RequestParam String employerId,@RequestParam String password,@RequestParam String newPassword) {
        String msg = employerService.updatePass(Long.valueOf(employerId), password, newPassword);
        return R.success(msg);
    }
}
