package com.yuu.recruit.controller;

import com.yuu.recruit.common.R;
import com.yuu.recruit.domain.Employee;
import com.yuu.recruit.service.EmployeeService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.List;

/**
 * 管理员雇员管理控制器
 *
 * @author by yuu
 * @Classname AdminEmployeeController
 * @Date 2019/10/14 9:48
 * @see com.yuu.recruit.controller
 */
@RestController
@RequestMapping("admin/employee")
public class AdminEmployeeController {

    @Resource
    private EmployeeService employeeService;

    @GetMapping("")
    public R<List<Employee>> taskCategory() {
        List<Employee> employees = employeeService.getAll();
        return R.success(employees);
    }
}
