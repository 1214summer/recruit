package com.yuu.recruit.controller;

import com.yuu.recruit.common.R;
import com.yuu.recruit.domain.Employee;
import com.yuu.recruit.service.EmployeeService;
import com.yuu.recruit.service.EmployerService;
import com.yuu.recruit.service.TaskService;
import com.yuu.recruit.domain.Admin;
import com.yuu.recruit.service.AdminService;
import com.yuu.recruit.vo.TaskVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.List;
import java.util.Objects;

/**
 * 管理员控制器
 *
 * @author by yuu
 * @Classname AdminController
 * @Date 2019/10/13 16:26
 * @see com.yuu.recruit.controller
 */
@Slf4j
@RestController
@RequestMapping("admin")
public class AdminController {

    /**
     * Spring 容器自动注入 AdminService
     */
    @Resource
    private AdminService adminService;

    @Resource
    private EmployerService employerService;

    @Resource
    private EmployeeService employeeService;

    @Resource
    private TaskService taskService;

    /**
     * 管理员登录
     *
     * @param admin 管理员，在参数上使用实体类接收，可以自动接受 username,password 属性
     * @return
     */
    @CrossOrigin(origins = "http://localhost:5173", allowCredentials = "true")
    @PostMapping("login")
    public R<Admin> login(HttpServletRequest request, @RequestBody Admin admin) {

        // 调用 AdminService 处理登录的业务逻辑，返回一个 Admin 对象，如果为空登录失败，如果不为空登录成功
        Admin currAdmin = adminService.login(admin);
        log.info(String.valueOf(request));
        log.info(String.valueOf(currAdmin));
        if (currAdmin == null) {
            return R.error("用户名或密码错误");
        } else {
            request.getSession().setAttribute("admin", currAdmin.getId());
            log.info(currAdmin.toString());
            return R.success(currAdmin);
        }
    }

    /**
     * 退出登录
     *
     * @return
     */
    @CrossOrigin(origins = "http://localhost:5173", allowCredentials = "true") // 允许携带凭据)
    @PostMapping("/logout")
    public R<String> logout(HttpServletRequest request) {
        //清理Session中保存的当前登录员工的id
        log.info(String.valueOf(request.getSession()));
        request.getSession().removeAttribute("admin");
        return R.success("退出成功");
    }
}