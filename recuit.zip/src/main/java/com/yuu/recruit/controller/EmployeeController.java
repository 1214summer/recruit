package com.yuu.recruit.controller;

import com.yuu.recruit.common.R;
import com.yuu.recruit.domain.*;
import com.yuu.recruit.service.*;
import com.yuu.recruit.vo.*;
import com.yuu.recruit.service.BidService;
import com.yuu.recruit.service.EmployeeService;
import com.yuu.recruit.service.HomeBowerService;
import com.yuu.recruit.service.TaskService;
import com.yuu.recruit.vo.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.websocket.server.PathParam;
import java.util.List;

/**
 * 雇员控制器
 *
 * @author by yuu
 * @Classname EmployeeController
 * @Date 2019/10/15 0:36
 * @see com.yuu.recruit.controller
 */
@RestController
@Slf4j
@RequestMapping("employee")
public class EmployeeController {

    @Resource
    private EmployeeService employeeService;

    @Resource
    private TaskService taskService;

    @Resource
    private HomeBowerService homeBowerService;

    @Resource
    private EmployeeBookmarkedService employeeBookmarkedService;

    @Resource
    private BidService bidService;


    /**
     * 跳转到个人中心
     *
     * @return
     */
    @PostMapping("getInfo")
    public R<Employee> dashboard(@RequestBody Employee employee) {
        return R.success(employee);
    }

    @PostMapping("BidCount")
    public R<Integer> dashboard1(HttpServletRequest request){
        Employee employee = (Employee) request.getSession().getAttribute("employee");
        Integer bidCount = taskService.getByBidEmployeeId(employee.getId());
        return R.success(bidCount);

    }


    /**
     * 收藏或取消收藏任务
     *
     * @param taskId
     * @return
     */
    @GetMapping("bookmarked")
    public R<EmployeeBookmarked> bookmarked(@RequestParam String employeeId,@RequestParam Long taskId) {
        if (employeeId == null){
            return R.error("未登陆或已失效");
        }
        // 收藏或取消收藏任务
        EmployeeBookmarked employeeBookmarked = employeeBookmarkedService.bookmarked(Long.valueOf(employeeId), taskId);
        return R.success(employeeBookmarked);
    }

    @GetMapping("bookmarks")
    public R<List<EmployeeBookmarkedVo>> bookmarks(@RequestParam String employeeId) {
        List<EmployeeBookmarkedVo> bookMarks = employeeBookmarkedService.getByEmployeeId(Long.valueOf(employeeId));
        return R.success(bookMarks);
    }

    @GetMapping("bookmarks/remove")
    public R<String> bookmarks(@RequestParam String employeeId,@RequestParam Long taskId) {
        employeeBookmarkedService.remove(Long.valueOf(employeeId), taskId);
        return R.success("删除成功");
    }


    /**
     * 查询已完成任务
     *
     * @return
     */
    @GetMapping("/task/completed")
    public R<List<TaskVo>> completedTask(@RequestParam String employeeId) {
        List<TaskVo> taskVos = taskService.getCompletedByEmployeeId(Long.valueOf(employeeId));
        return R.success(taskVos);
    }

    /**
     * 待完成任务
     *
     * @return
     */
    @GetMapping("/task/uncompleted")
    public R<List<TaskVo>> unCompletedTask(@RequestParam String employeeId) {
        // 查询出未完成的订单
        List<TaskVo> taskVos = taskService.getUnCompletedByEmployeeId(Long.valueOf(employeeId));

        return R.success(taskVos);
    }

    /**
     * 雇员提交任务
     *
     * @param
     * @return
     */
    @GetMapping("/task/submit")
    public R<String> submitTask(@RequestParam String employeeId,@RequestParam Long taskId) {
        // 雇员提交信息
        taskService.submitTask(Long.valueOf(employeeId), taskId);

        return R.success("提交成功，等待确认");
    }

    /**
     * 我的竞标
     *
     * @param
     * @return
     */
    @GetMapping("mybids")
    public R<List<BidVo>> myBid(@RequestParam String employeeId) {
        List<BidVo> bidVos = bidService.getNoBitByEmployeeId(Long.valueOf(employeeId));
        return R.success(bidVos);
    }

    /**
     * 删除竞标信息
     *
     * @param bid
     * @return
     */
    @GetMapping("bid/delete")
    public R<String> deleteBid(@RequestParam Long bid) {
        bidService.deleteById(bid);
        return R.success("删除成功");
    }

    /**
     * 跳转到个人信息设置页面
     *
     * @return
     */
    @GetMapping("settings/base")
    public R<EmployeeVo> settings(@RequestParam String employeeId) {
        EmployeeVo employeeVo = employeeService.getById(Long.valueOf(employeeId));
        return R.success(employeeVo);
    }

    /**
     * 保存个人基本信息
     *
     * @param employee
     * @return
     */
    //storage
    @PostMapping("settings/base/save")
    public R<Employee> saveBase(@RequestBody Employee employee) {
        // 更新个人信息到数据库
        Employee currEmployee = employeeService.save(employee);
        return R.success(currEmployee);
    }

    /**
     * 修改密码
     *
     * @param password 原来的密码
     * @param newPassword 新密码
     * @return
     */
    @GetMapping("settings/password")
    public R<String> updatePass(@RequestParam String employeeId,@RequestParam String password,@RequestParam String newPassword) {
        String msg = employeeService.updatePass(Long.valueOf(employeeId), password, newPassword);
        return R.success(msg);
    }

    /**
     * 跳转到雇员简介页面
     *
     * @return
     */
    @GetMapping("employeeProfile")
    public R<EmployeeVo> profile(@RequestParam Long employeeId) {
        // 查询雇员信息
        EmployeeVo employee = employeeService.getById(employeeId);
        return R.success(employee);
    }

    @GetMapping("historyTask")
    public R<List<TaskVo>> profile1(@RequestParam Long employeeId) {
        // 查询历史完成任务
        List<TaskVo> taskVos = taskService.getByEmployeeId(employeeId);
        return R.success(taskVos);
    }

    @GetMapping("totalTask")
    public R<Integer> profile2(@RequestParam Long employeeId) {
        //查询雇员总完成任务数
        Integer completeCount = taskService.getCompletedByEmployeeId(employeeId).size();
        return R.success(completeCount);
    }

    /**
     * 添加技能
     *
     * @param skillName 技能名称
     * @return
     */
    @PostMapping("skill/add")
    public R<String> addSkill(@RequestParam String skillName, @RequestBody Employee employee) {
//        Employee employee = (Employee) request.getSession().getAttribute("employee");

        if (!"".equals(skillName)) {
            employeeService.addSkill(employee.getId(), skillName);
        }
        return R.success("添加技能成功");
    }

    /**
     * 删除技能
     *
     * @param skillId
     * @return
     */
    @PostMapping("skill/delete")
    public R<String> deleteSkill(@RequestParam Long skillId) {
        employeeService.deleteSkill(skillId);
        return R.success("删除技能成功");
    }

}
