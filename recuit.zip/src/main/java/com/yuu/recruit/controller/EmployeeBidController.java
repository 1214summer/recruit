package com.yuu.recruit.controller;

import cn.hutool.core.date.DateField;
import cn.hutool.core.date.DateUtil;
import com.yuu.recruit.common.R;
import com.yuu.recruit.consts.BidStatus;
import com.yuu.recruit.domain.Bid;
import com.yuu.recruit.domain.Employee;
import com.yuu.recruit.service.BidService;
import com.yuu.recruit.service.TaskService;
import com.yuu.recruit.utils.IDUtil;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.Date;

/**
 * @see com.yuu.recruit.controller
 */
@RestController
public class EmployeeBidController {

    @Resource
    private BidService bidService;

    @Resource
    private TaskService taskService;

    /***
     *
     * @param employeeId
     * @param taskId
     * @param bidPrice
     * @param timeNumber
     * @param timeType
     * @return
     */
    @GetMapping("employee/bid")
    public R<Bid> bid(@RequestParam String employeeId, @RequestParam Long taskId, @RequestParam Double bidPrice, @RequestParam int timeNumber,@RequestParam String timeType) {

        // 判断雇员是否已经投标该任务
        boolean flag = bidService.getBidByTaskIdAndEmployeeId(taskId, Long.valueOf(employeeId));
        if (flag) {
            return R.error("已投标过");
        }

        // 创建一个投标对象，设置值
        Bid bid = new Bid();
        bid.setId(IDUtil.getRandomId());
        bid.setTaskId(taskId);
        bid.setEmployeeId(Long.valueOf(employeeId));
        bid.setBidPrice(bidPrice);
        String deliveryDesc = timeNumber + timeType;
        bid.setDeliveryDesc(deliveryDesc);
        bid.setBidStatus(BidStatus.NO_BIT);

        // 计算到期时间
        Date deliveryTime = null;
        if ("小时".equals(timeType)) {
            deliveryTime = DateUtil.offset(new Date(), DateField.HOUR, timeNumber);
        } else if ("天".equals(timeType)) {
            deliveryTime = DateUtil.offset(new Date(), DateField.DAY_OF_MONTH, timeNumber);
        } else if ("月".equals(timeType)) {
            deliveryTime = DateUtil.offset(new Date(), DateField.MONTH, timeNumber);
        }
        bid.setDeliveryTime(deliveryTime);

        // 设置创建时间
        bid.setCreateTime(new Date());

        // 调用 bidService 添加到数据库
        bidService.bid(bid);

        // 下标成功，重定向到任务列表页
        return R.success(bid);
    }
}
